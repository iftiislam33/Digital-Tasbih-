# ডিজিটাল তাসবিহ — Android starter project

## ফিচার
- ডার্ক ইসলামিক UI
- এক ট্যাপে কাউন্টার
- ৩৩ / ৯৯ / ১০০ / ১০০০ লক্ষ্য
- জিকির তালিকা ও কাস্টম জিকির যোগ
- দৈনিক হিসাব
- ভাইব্রেশন চালু/বন্ধ
- SharedPreferences-এ লোকাল সংরক্ষণ; ইন্টারনেট ছাড়াই চলে

## চালানোর নিয়ম
1. Android Studio-তে এই ফোল্ডারটি Open করুন।
2. Gradle sync শেষ হতে দিন।
3. Android ফোন/এমুলেটর যুক্ত করে Run চাপুন।
4. APK বানাতে: Build > Build Bundle(s) / APK(s) > Build APK(s)।

Package: `com.example.digitaltasbih`
Min Android: 6.0 (API 23)
