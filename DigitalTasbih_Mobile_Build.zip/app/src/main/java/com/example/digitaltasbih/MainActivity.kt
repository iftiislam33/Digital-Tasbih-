package com.example.digitaltasbih

import android.content.Context
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B1412)
private val Panel = Color(0xFF14231F)
private val Green = Color(0xFF35C78A)
private val Gold = Color(0xFFE4C477)
private val Muted = Color(0xFF9FB3AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TasbihApp() }
    }
}

@Composable
fun TasbihApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tasbih", Context.MODE_PRIVATE) }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val defaultList = listOf("سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ", "أَسْتَغْفِرُ اللَّهَ", "لَا إِلَٰهَ إِلَّا اللَّهُ")
    var zikrList by remember { mutableStateOf(defaultList) }
    var selected by remember { mutableStateOf(prefs.getString("selected", defaultList[0]) ?: defaultList[0]) }
    var count by remember { mutableIntStateOf(prefs.getInt("count", 0)) }
    var target by remember { mutableIntStateOf(prefs.getInt("target", 33)) }
    var vibration by remember { mutableStateOf(prefs.getBoolean("vibration", true)) }
    var showHistory by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var newZikr by remember { mutableStateOf("") }
    var daily by remember { mutableStateOf(prefs.getString("daily", "{}") ?: "{}") }

    fun save() {
        prefs.edit().putInt("count", count).putInt("target", target)
            .putString("selected", selected).putBoolean("vibration", vibration)
            .putString("daily", daily).apply()
    }
    fun vibrate() {
        if (!vibration) return
        try {
            val v = if (android.os.Build.VERSION.SDK_INT >= 31) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(25, 80))
            else @Suppress("DEPRECATION") v.vibrate(25)
        } catch (_: Exception) { }
    }
    fun addOne() {
        count++
        val obj = try { JSONObject(daily) } catch (_: Exception) { JSONObject() }
        val todayObj = obj.optJSONObject(today) ?: JSONObject()
        todayObj.put(selected, todayObj.optInt(selected, 0) + 1)
        obj.put(today, todayObj)
        daily = obj.toString()
        save()
        vibrate()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ডিজিটাল তাসবিহ", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("জিকিরে প্রশান্তি", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !showHistory && !showList, onClick = { showHistory = false; showList = false }, label = { Text("তাসবিহ") })
                FilterChip(selected = showList, onClick = { showList = true; showHistory = false }, label = { Text("জিকির") })
                FilterChip(selected = showHistory, onClick = { showHistory = true; showList = false }, label = { Text("দৈনিক হিসাব") })
            }
            Spacer(Modifier.height(16.dp))
            when {
                showHistory -> HistoryView(daily)
                showList -> {
                    Text("জিকির নির্বাচন করুন", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(Modifier.weight(1f, fill = false)) {
                        items(zikrList) { item ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                .background(if (selected == item) Panel else Color.Transparent, RoundedCornerShape(12.dp))
                                .clickable { selected = item; count = 0; save() }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(item, color = if (selected == item) Green else Color.White, modifier = Modifier.weight(1f), fontSize = 20.sp)
                                if (selected == item) Text("নির্বাচিত", color = Gold, fontSize = 12.sp)
                            }
                        }
                    }
                    OutlinedTextField(value = newZikr, onValueChange = { newZikr = it },
                        label = { Text("নতুন জিকির লিখুন") }, singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                    Button(onClick = { if (newZikr.isNotBlank() && !zikrList.contains(newZikr.trim())) { zikrList = zikrList + newZikr.trim(); newZikr = "" } },
                        colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("জিকির যোগ করুন", color = Bg) }
                }
                else -> {
                    Text(selected, color = Color.White, fontSize = 25.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text("লক্ষ্য: $target", color = Muted)
                    Box(Modifier.size(250.dp).background(Panel, CircleShape).padding(10.dp)
                        .background(Color(0xFF1C342C), CircleShape).clickable { addOne() },
                        contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(count.toString(), color = Green, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                            Text("ট্যাপ করে গণনা করুন", color = Muted, fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(33, 99, 100, 1000).forEach { n ->
                            FilterChip(selected = target == n, onClick = { target = n; save() }, label = { Text("$n") })
                        }
                    }
                    if (count >= target) Text("আলহামদুলিল্লাহ! লক্ষ্য পূরণ হয়েছে।", color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { count = (count - 1).coerceAtLeast(0); save() }) { Text("এক ধাপ কমান", color = Color.White) }
                        Button(onClick = { count = 0; save() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9C514B))) { Text("রিসেট") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ভাইব্রেশন", color = Muted)
                        Switch(checked = vibration, onCheckedChange = { vibration = it; save() })
                    }
                    Text("আপনার গণনা এই ডিভাইসেই সংরক্ষিত হয়", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun HistoryView(daily: String) {
    val obj = remember(daily) { try { JSONObject(daily) } catch (_: Exception) { JSONObject() } }
    val keys = remember(daily) { obj.keys().asSequence().toList().sortedDescending() }
    Column(Modifier.fillMaxWidth()) {
        Text("দৈনিক জিকিরের হিসাব", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (keys.isEmpty()) Text("এখনো কোনো হিসাব নেই।", color = Muted)
        else LazyColumn {
            items(keys) { day ->
                val dayObj = obj.optJSONObject(day) ?: JSONObject()
                val total = dayObj.keys().asSequence().sumOf { dayObj.optInt(it, 0) }
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)) {
                    Text(day, color = Gold, fontWeight = FontWeight.Bold)
                    Text("মোট জিকির: $total", color = Color.White)
                    dayObj.keys().asSequence().forEach { zikr ->
                        Text("$zikr  —  ${dayObj.optInt(zikr)}", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
